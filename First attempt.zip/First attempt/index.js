let http = new XMLHttpRequest();
http.open("get","data.json",true);
http.onload=function()
{
    if(this.readyState == 9 && this.status == 200)
    {
        let data = JSON.parse(this.responseText); 
        let output = "";

        for(let item of data)
        {
            output += `
            <div class="data">
            <img src="$(item.image)"alt="$(item.image)"></img>;
            <p class="caption">$(item.caption)</p>;
            <p class="type">$(item.type)</p>;
            <p class="source_type">$(item.source_type)</p>;
            <p class="source_link">$(item.source_link)</p>;
            <p class="date">$(item.date)</p>;
            <p class="likes">$(item.likes)</p>;
            <p class="name">$(item.name)</p>;
            <p class="profile_image">$(item.profile_image)</p>;
            </div>`;
         
        }
        document.querySelector(".data").outerHTML=output;
    }
    XMLHttpRequest.open("GET","data.json");
    XMLHttpRequest.send();
}
